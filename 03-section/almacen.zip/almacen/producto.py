import csv

class Producto:
    nombre = ''
    precio = 0
    descuento = 0
    iva = 0
    # ruta = '/ruta/carpeta/almacen/ventas.csv'         # Para linux
    ruta = r'C:\\ruta\carpeta\almacen\ventas.csv'       # Para windows

    def __init__ (self,nombre, precio):
        self.nombre = nombre
        self.precio = precio
        # calcular descuento automatico al crear la un obejto de la clase
        # calcular iva automatico al crear la un obejto de la clase
        
    def calcular_descuento(self):
        descuento = 0
        # si el precio es > 100 descuento de 15%
        # si no descuento de 5%            
        return round(descuento, 2)

    def calcular_iva(self):
        iva = 0
        # calcular el iva
        return iva

    def modificar_precio (self, precio):
        # actualizar el nuevo precio
        # calcular el descuento usando el nuevo precio
        # calcular el iva usando el nuevo precio
        pass

    def mostrar (self):
        # mostrar los datos del producto.
        pass

    def leer_csv(self):
        resultado = []
        with open(self.ruta, 'r') as archivo:
            datos_csv = csv.DictReader(archivo)
            for fila in datos_csv:
                resultado.append(fila)
        return resultado

    def registrar_csv(self, fila):
        data = self.leer_csv()
        id = int(data[-1]['id'])+1
        fila['id'] = id
        with open(self.ruta, 'a', newline='') as f:
            escritura = csv.DictWriter(f, fieldnames=fila.keys())
            escritura.writerow(fila)