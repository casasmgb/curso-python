from producto import Producto
from cliente import Cliente
from venta import Venta

# crear un producto, mostrar, modificar precio y mostrar

# crear cliente

# crear venta usando (cliente y producto)
# armar los datos de venta
# guardar la venta
