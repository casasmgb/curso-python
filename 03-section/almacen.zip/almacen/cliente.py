class Cliente:
    codigo = 0
    nombre = ''

    # def __init__ (self, codigo, nombre):
    #     self.codigo = codigo
    #     self.nombre = nombre

    def mostrar (self):
        # mostrar datos del cliente codigo, nombre
        pass 

    def crear(self, codigo_nuevo, nombre_nuevo):
        # asignar los datos del cliente 
        pass

    def modificar_nombre(self, nombre_modificado):
        # reasignar el nombre del cliente 
        pass

    