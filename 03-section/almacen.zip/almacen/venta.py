class Venta:
    
    nueva_venta = {}
    
    def __init__(self, cliente_nuevo, producto_nuevo):
        self.cliente = cliente_nuevo
        self.producto = producto_nuevo

    def armar_diccionario (self):
        self.nueva_venta = {
            'id': 0,
            'codigo_cliente': 0, # acceder al codigo del cliente
            'cliente': '',       # acceder al nombre del cliente
            'producto': '',      # acceder al nombre del producto
            'precio': 0.0,       # acceder al precio del producto
            'descuento': 0.0,    # acceder al descuento del producto
            'iva': 0.0,          # acceder al iva del producto 
        }

        return self.nueva_venta

    def guardar_venta (self):
        self.producto.registrar_csv(self.nueva_venta)