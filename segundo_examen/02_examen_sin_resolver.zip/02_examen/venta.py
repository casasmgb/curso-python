import csv

class Venta:
    nueva_venta = {}
    ruta = '/home/gcasas/Downloads/02_examen/ventas.csv'

    def crear(self, cliente, producto):
        self.cliente = cliente
        self.producto = producto

    def leer_csv(self):
        resultado = []
        with open(self.ruta, 'r') as archivo:
            datos_csv = csv.DictReader(archivo)
            for fila in datos_csv:
                resultado.append(fila)
        return resultado

    def registrar_csv(self, fila):
        data = self.leer_csv()
        id = int(data[-1]['id_producto'])+1
        fila['id_producto'] = id
        with open(self.ruta, 'a', newline='') as f:
            escritura = csv.DictWriter(f, fieldnames=fila.keys())
            escritura.writerow(fila)

    def armar_diccionario (self):
        self.nueva_venta = {
            'id_producto': 0,
            'codigo_cliente': self.cliente.codigo, 
            'cliente': self.cliente.nombre, 
            'producto': self.producto.nombre, 
            'precio': self.producto.precio, 
            'descuento': self.producto.descuento, 
            'iva': self.producto.iva, 
        }

    def guardar_venta (self):
        self.armar_diccionario()
        self.registrar_csv(self.nueva_venta)