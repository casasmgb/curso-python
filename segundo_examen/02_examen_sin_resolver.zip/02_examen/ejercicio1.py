from producto import Producto
from cliente import Cliente
from venta import Venta
from factura import Factura

producto = Producto('pan', 100.6)
producto.mostrar()

cliente = Cliente(1000, 'Armando Calle')
cliente.mostrar()

venta = Venta()
venta.crear(cliente, producto)
venta.guardar_venta()
