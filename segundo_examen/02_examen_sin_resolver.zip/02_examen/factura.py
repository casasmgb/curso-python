import csv

class Factura():
    nueva_factura = {}
    ruta = '/home/gcasas/Downloads/02_examen/facturas.csv'
