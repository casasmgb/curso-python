from producto import Producto
from cliente import Cliente
from venta import Venta
from factura import Factura

venta = Venta()
